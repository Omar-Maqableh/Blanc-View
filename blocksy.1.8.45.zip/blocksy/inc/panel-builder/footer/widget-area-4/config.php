<?php

$config = [
	'name' => __('Widget Area 4', 'blocksy')
];



