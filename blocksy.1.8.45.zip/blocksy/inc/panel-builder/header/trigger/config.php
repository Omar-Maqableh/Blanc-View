<?php

$config = [
	'name' => __('Trigger', 'blocksy'),
	'devices' => ['mobile'],
	'shortcut_style' => 'drop',
	'excluded_from' => ['offcanvas']
];