<?php

$options = apply_filters('blocksy:header:settings', [
]);
