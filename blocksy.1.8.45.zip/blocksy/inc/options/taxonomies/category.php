<?php

$options = [
	/*
	blocksy_get_options('general/page-title', [
		'has_default' => true,
		'is_archive' => true
	])
	 */

	'asd' => [
		'type' => 'text',
		'value' => 123
	]
];
